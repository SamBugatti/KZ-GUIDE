<!doctype html>

<html>

<head>

<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
* {box-sizing: border-box}

/* Full-width input fields */
  input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
    width: 100%;
  }
}


/* The message box is shown when the user clicks on the password field */
#message {
  display:none;
  background: #f1f1f1;
  color: #000;
  position: relative;
  padding: 20px;
  margin-top: 10px;
}

#message p {
  padding: 10px 35px;
  font-size: 18px;
}

#messag {
  display:none;
  background: #f1f1f1;
  color: #000;
  position: relative;
  padding: 20px;
  margin-top: 10px;
}

#messag p {
  padding: 10px 35px;
  font-size: 18px;
}

/* Add a green text color and a checkmark when the requirements are right */
.valid {
  color: green;
}

.valid:before {
  position: relative;
  left: -35px;
  content: "✔";
}

/* Add a red text color and an "x" when the requirements are wrong */
.invalid {
  color: red;
}

.invalid:before {
  position: relative;
  left: -35px;
  content: "✖";
}

</style>

</head>

<body>

    <form action="validation-form/check.php" method="post" style="border:1px solid #ccc; margin: 70px 300px">
    <div class="container">
      <?php
      if($_COOKIE['user'] == ''):
      ?>

    <center>
    <img height="10%" width="10%" src="images/profile photo.jpg"/>
    <h1>Sign Up</h1>
    <p>Please fill in this form to create an account.</p>
    </center>
    <hr>
    <label><b>Login</b></label>
    <input type="text" class="form-control" name="login" id="login" placeholder="Enter your login"> <br>
    
    <label><b>Name</b></label>
    <input type="text" class="form-control" name="name" id="name" placeholder="Enter your name"> <br>

    <label for="psw"><b>Password</b></label>
    <input type="password" class="form-control" name="password" id="password" placeholder="Enter your password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required> <br>
    
    <div id="message" style="margin: 5px 0 22px 0">
  <h3>Password must contain the following:</h3>
  <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
  <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
  <p id="number" class="invalid">A <b>number</b></p>
  <p id="length" class="invalid">Minimum <b>8 characters</b></p>
    </div>

<script>
var myInput = document.getElementById("password");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
  document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
  document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }

  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }

  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}
</script>

    <label for="pswrepeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" id="pswrepeat" name="pswrepeat" required>

     <div id="messag" style="margin: 5px 0 22px 0">
    <h3>Must contain the following:</h3>
    <p id="same" class="invalid">The <b>same</b> password</p>
     </div>

    <script>
    var repeatMyPsw = document.getElementById("pswrepeat");
    var password = document.getElementById("password");
    var same = document.getElementById("same");

    // When the user clicks on the password field, show the message box
    repeatMyPsw.onfocus = function() {
    document.getElementById("messag").style.display = "block";
    }

    // When the user clicks outside of the password field, hide the message box
    repeatMyPsw.onblur = function() {
    document.getElementById("messag").style.display = "none";
    }

    // When the user starts to type something inside the password field
    repeatMyPsw.onkeyup = function() {

    // Validate if they same
    if (repeatMyPsw.value == password.value){
    same.classList.remove("invalid");
    same.classList.add("valid");

    }
    else{
    same.classList.remove("valid");
    same.classList.add("invalid");
    }
    }
    </script>

    <p style="margin: 5px 0 22px 0; color: red">*Only Latin letters are accepted</p>

    <label>
      <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
    </label>

    <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

    <div class="clearfix">
      <a href="index.html"><button type="button" class="cancelbtn"> Cancel </button></a>
      <a href="personal page.html"><button type="submit" class="signupbtn"> Sign up </button></a>
    </div>
    <?php else:;
 ?>

 <p>Hello! <?=$_COOKIE['user']?>. If you want to exit from your account, press <a href="/validation-form/exit.php"> here </a>.</p>

 <?php endif;
 ?>
    </div>
    </form>

</body>

</html>
<?php 
   require_once 'include/db.php';
?>