<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kzguide";
$conn = mysqli_connect($servername, $username, $password, $dbname);

ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
} else {
    // echo "Connected successfully";
}
$search  = $_POST['search'];
$ascdesc = (isset($_POST['change'])) ? 'asc' : 'desc';

$sql = "SELECT * FROM `Tours` WHERE  Name LIKE '%$search%' ORDER BY price $ascdesc ";
$res = mysqli_query($conn, $sql);


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>KZ GUIDE</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>
    <section class="bannerWorks">
        <header id="header">
            <div class="header-content clearfix">
                <a class="logo" style="font-family: 'Segoe UI';text-transform:uppercase;font-weight: 600;color: #ffffff;text-decoration:none;font-size: 20px;" href="index.php">KZ Guide</a>
                <nav class="navigation" role="navigation">
                    <ul class="primary-nav">
                        <li><a href="index.php">Features</a></li>
                        <li><a href="index.php">Works</a></li>

                        <li><a href="index.php">Testimonials</a></li>

                    </ul>
                </nav>
                <a href="#" class="nav-toggle">Menu<span></span></a>
            </div>
        </header>
    </section>
    <section>
        <div class="container">
            <form action="" method="post">
                <input type="hidden" value="t">
                
                <button class="btn info" name="change">Decriment</button>
                
            </form>
        </div>
        <?php
        while ($row = $res->fetch_assoc()) {
            echo '<div class="container" style="height:250px; width: 100%;">
            <div class="row">
                <div class="col-sm-4">
                    <img src="' . $row['LINKPHT'] . '" class="img-fluid" alt="image of product">
                </div>
                <div class="col-sm-8">
                    <div class="wraperr" style="border-left: 5px solid blue; padding-left:20px">
                        <div>
                            <h2> <a href="./product.php"> ' . $row['Name'] . ' </a></h2>
                        </div>
                        <div>
                            <p>' . $row['Price'] . '</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>';
        }
        ?>
    </section>

</body>

</html>
