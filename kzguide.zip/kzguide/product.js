function alt()
{
    alert('Be respectfull for each other');
    
}