<!doctype html>
<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>KZ GUIDE</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
          rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
          crossorigin="anonymous">
</head>
<body>
<section class="bannerWorks">
    <header id="header">
        <div class="header-content clearfix">
            <a class="logo"
               style="font-family: 'Segoe UI';text-transform:uppercase;font-weight: 600;color: #ffffff;text-decoration:none;font-size: 20px;"
               href="index.php">KZ Guide</a>
            <nav class="navigation" role="navigation">
                <ul class="primary-nav">
                    <li><a href="index.php">Features</a></li>
                    <li><a href="index.php">Testimonials</a></li>

                </ul>
            </nav>
            <a href="#" class="nav-toggle">Menu<span></span></a>
        </div>
    </header>
</section>


<section id="values" class="values">

    <div class="container" data-aos="fade-up">

        <header class="section-header">
            <h2>Our Tours</h2>
        </header>

        <div class="row">

            <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
                <div class="box">
                    <img src="https://explorekazakhstan.net/wp-content/uploads/2021/02/4.jpg" class="img-fluid" alt="">
                    <a href="product.html">ASSY PLATEAU - TURGEN GORGE ONE DAY JEEP TOUR</a>
                    <p style="text-align:left;padding-left: 20px;">Price: 23 000 tg.</p>
                </div>
            </div>

            <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="400">
                <div class="box">
                    <img src="https://explorekazakhstan.net/wp-content/uploads/2021/02/2-DAYS-VIP-TRACK.jpg" class="img-fluid" alt="">
                    <a href="product.html">TWO DAYS VIP TOUR. ASSY PLATEAU - BARTOGAY RESERVOIR - RAFTING ON THE CHILIK RIVER 3 KM</a>
                    <p style="text-align:left;padding-left: 20px;">Price: 23 000 tg.</p>
                </div>
            </div>

            <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
                <div class="box">
                    <img src="https://explorekazakhstan.net/wp-content/uploads/2021/02/e5671507ff8ac1aaffed73d9feb453e9-1024x683.jpg" class="img-fluid" alt="">
                    <a href="product.html">JOURNEY IN SOUTHERN KAZAKHSTAN. SHYMKENT - TARAZ - TURKESTAN</a>
                    <p style="text-align:left;padding-left: 20px;">Price: 23 000 tg.</p>
                </div>
            </div>

            <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
                <div class="box">
                    <img src="https://explorekazakhstan.net/wp-content/uploads/2021/02/1Рафтинг-1024x576.jpg" class="img-fluid" alt="">
                    <a href="product.html">RAFTING ALONG THE RIVER OR TO THE TAMGALY-TAS STORE (ANCIENT BUDDHIST TEMPLE)</a>
                    <p style="text-align:left;padding-left: 20px;">Price: 23 000 tg.</p>
                </div>
            </div>

            <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="400">
                <div class="box">
                    <img src="https://explorekazakhstan.net/wp-content/uploads/2021/02/Горячие-Источники-Чунджа-—-Чарынский-Каньон-–-Озера-Кольсай-И-Кайынды-1024x576.jpg" class="img-fluid" alt="">
                    <a href="product.html">CHUNJA HOT SPRINGS - CHARYNSKY CANYON - KOLSAY AND KAYYNDY LAKE</a>
                    <p style="text-align:left;padding-left: 20px;">Price: 23 000 tg.</p>
                </div>
            </div>

            <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
                <div class="box">
                    <img src="https://explorekazakhstan.net/wp-content/uploads/2021/02/я8a9a82a259ea083af0765de9df24108d.jpeg" class="img-fluid" alt="">
                    <a href="product.html">CHARYNSKY CANYON AND BARTOGAY RESERVOIR</a>
                    <p style="text-align:left;padding-left: 20px;">Price: 23 000 tg.</p>
                </div>
            </div>

        </div>

    </div>

</section>

<footer class="footer">
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="footer-col col-md-4">
                    <h5>Location</h5>
                    <p>Mangilik El, C1 <br>
                        <span>+7 747 294 64 20 </span><br>
                        <span>info_kzguide@gmail.com</span></p>
                </div>
                <div class="footer-col col-md-4">
                    <h5>Share with Love</h5>
                    <ul class="footer-share" style="margin-left: -30px">
                      <li><a href=" https://www.facebook.com/KZ-GUIDE-101718922516197 " id="facebook"><i class="fa fa-facebook"></i></a></li>
                      <li><a href="https://www.instagram.com/kzguide_aitu/"><i class="fa fa-instagram" aria-hidden="true"></i>

                      <li><a href="bugattysam@gmail.com"><i class="fa fa-google-plus"></i></a></li>

                    </ul>

                </div>
                <div class="footer-col col-md-4">
                  <h5>About Us</h5>
                    <p>EXCLUSIVE TOURS IN CENTRAL ASIA.</p>

                </div>
            </div>
        </div>
    </div>
</footer>
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script>
</body>
</html>

<?php 
   require_once 'include/db.php';
?>
