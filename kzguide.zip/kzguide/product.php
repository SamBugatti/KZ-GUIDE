<!doctype html>
<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Title</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
          rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
          <script src="product.js"></script>
        </head>
<body>
<section class="bannerWorks" role="banner">
    <header id="header">
        <div class="header-content clearfix">
            <a class="logo"
               style="font-family: 'Segoe UI';text-transform:uppercase;font-weight: 600;color: #ffffff;text-decoration:none;font-size: 20px;"
               href="index.php">KZ Guide</a>
            <nav class="navigation" role="navigation">
                <ul class="primary-nav">
                    <li><a href="index.php">Features</a></li>
                    <li><a href="works.php">Works</a></li>
                    <li><a href="index.php">Our Team</a></li>
                    <li><a href="index.php">Testimonials</a></li>
                    <li><a href="index.php">Download</a></li>
                </ul>
            </nav>
            <a href="#" class="nav-toggle">Menu<span></span></a>
        </div>
    </header>
</section>


<section class="product">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="https://explorekazakhstan.net/wp-content/uploads/2021/02/1SOUTH-KAZAKHSTAN-3.jpg" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="https://explorekazakhstan.net/wp-content/uploads/2021/02/e5671507ff8ac1aaffed73d9feb453e9.jpg" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="https://explorekazakhstan.net/wp-content/uploads/2021/02/1583336050610.jpg" class="d-block w-100" alt="...">
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        Tour description
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Southern Kazakhstan</h5>
                        <p class="card-text">
                        <div class="tour-description">

                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Southern Kazakhstan is a unique place with hot desert sands, green meadows and mountains, as well as beautiful and picturesque cities and ancient history. </font><font style="vertical-align: inherit;">By purchasing tours to South Kazakhstan, you will discover the diversity of flora and fauna of this picturesque corner of Kazakhstan.&nbsp;</font></font></p>



                            <p><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Shymkent</font></font></strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> is the second largest city in Kazakhstan in terms of population, and is also the administrative center of the South Kazakhstan region. </font><font style="vertical-align: inherit;">The city is included in the state program "Cultural Heritage" as one of the objects for the study and preservation of historical monuments. </font><font style="vertical-align: inherit;">Now Shymkent is a modern beautiful city. </font><font style="vertical-align: inherit;">The city has theaters, restaurants, a network of comfortable hotels, where guests and tourists of the city will be received with special oriental hospitality.&nbsp;</font></font></p>



                            <p><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Taraz</font></font></strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> is one of the oldest cities in Kazakhstan. </font><font style="vertical-align: inherit;">He is credited with superiority in many ways: the first metropolis, the first mosque built in Kazakhstan, the first madrasah, and so on. </font><font style="vertical-align: inherit;">Since 2011, excavations have been resumed in the city. </font><font style="vertical-align: inherit;">This means that archaeologists still have to learn a lot about the mysteries and secrets of the ancient city.</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Maximum number of people in a group: 15.</font></font></p>



                            <p><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Tour program:</font></font></strong></p>



                            <p><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1 day:&nbsp;</font></font></strong></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">06:00 the driver picks you up from the specified destination</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">07:00 departure from Almaty</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Visit to Tamgaly Tas-UNESCO. </font><font style="vertical-align: inherit;">Excursion 1.5 hours</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Lunch (lunch boxes)</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Departure to the city of Taraz</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">18:30 dinner</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Overnight at the hotel in Taraz</font></font></p>



                            <p><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2 day:</font></font></strong></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">08:00 breakfast</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">09:00 visit to the local history museum of Taraz</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Departure to Kone-Taraz (ancient city); </font><font style="vertical-align: inherit;">excursion</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">13:00 lunch</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">15:00 visit to the Caravanserai "Tortkol"</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">18:30 dinner</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Overnight at the hotel in Taraz</font></font></p>



                            <p><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">3 day:</font></font></strong></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">08:00 breakfast</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">09:00 departure to the city of Shymkent</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">13:00 lunch</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Visit to Ak-Mechet cave</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">18:30 dinner</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Overnight in Shymkent</font></font></p>



                            <p><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Day 4:&nbsp;</font></font></strong></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">08:00 breakfast</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">08:30 departure to the city of Otyrar</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">10:00 arrival, rest</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">13:00 lunch</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">14:00 visit to the Mausoleum of Arystan-Bab; </font><font style="vertical-align: inherit;">excursion</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">18:00 dinner</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">19:00 departure to the city of Turkestan (1 hour on the way)</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">20:00 arrival</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Overnight in Turkestan</font></font></p>



                            <p><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Day 5:&nbsp;</font></font></strong></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">07:00 breakfast</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">08:30 free time in Turkestan (visiting sights and holy places)</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">19:00 dinner</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">20:30 overnight at the hotel in the city of Turkestan</font></font></p>



                            <p><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Day 6:</font></font></strong></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">07:00 breakfast</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">08:30 departure to the city of Almaty</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">On the way visit the Palace complex "Akyrtas"</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Lunch in the city of Taraz&nbsp;</font></font></p>



                            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">21:00 Arrival in Almaty&nbsp;</font></font></p>



                            <figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio"><div class="wp-block-embed__wrapper">
                                <iframe loading="lazy" title="Turkistan/Explore Kazakhstan" width="500" height="281" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/TszmWiGkyyg?feature=oembed" class=" lazyloaded"></iframe>
                            </div></figure>



                            <p><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Cost: from 203.000 KZT (per person)</font></font></strong></p>



                            <p><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Season: all year (best time September-May)</font></font></strong></p>



                            <p><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Price may vary depending on the season</font></font></strong></p>
                        </div>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Saparova Assemgul</h5>
                                <p class="card-text">COOL PLACE!!!</p>
                                <a href="#" class="btn btn-primary">Like</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Kuzbakova Kamilla</h5>
                                <p class="card-text">I FELL IN LOVE WITH THIS PLACE</p>
                                <a href="#" class="btn btn-primary">Like</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>

<div id='form'>
    <div class="row">
    <div class="col-md-12">
    <div class="d-flex justify-content-center">
    <form action="" method="POST" id="commentform">

    <div id="comment-name" class="form-row">
    <input type = "text" placeholder = "Name (required)" name = "dname"  id = "name" >
    </div>
    <div id="comment-message" class="form-row">
    <textarea name = "comment" placeholder = "Message" id = "comment"  onkeypress="alt()" ></textarea>
    </div>
    <a href="#"><input type="submit" name="dsubmit" id="commentSubmit" value="Submit Comment"></a>


    </form>
    </div>
    </div>


<footer class="footer">
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="footer-col col-md-4">
                    <h5>Location</h5>
                    <p>Mangilik El, C1 <br>
                        <span>+7 747 294 64 20 </span><br>
                        <span>info_kzguide@gmail.com</span></p>
                </div>
                <div class="footer-col col-md-4">
                    <h5>Share with Love</h5>
                    <ul class="footer-share" style="margin-left: -30px">
                      <li><a href=" https://www.facebook.com/KZ-GUIDE-101718922516197 " id="facebook"><i class="fa fa-facebook"></i></a></li>
                      <li><a href="https://www.instagram.com/kzguide_aitu/"><i class="fa fa-instagram" aria-hidden="true"></i>

                      <li><a href="bugattysam@gmail.com"><i class="fa fa-google-plus"></i></a></li>

                    </ul>

                </div>
                <div class="footer-col col-md-4">
                    <h5>About Us</h5>
                    <p>EXCLUSIVE TOURS IN CENTRAL ASIA.</p>

                </div>
            </div>
        </div>
    </div>
</footer>
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>
<?php 
   require_once 'include/db.php';
?>