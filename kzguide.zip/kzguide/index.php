<!doctype html>
<head>
    <link rel="stylesheet" type="text/css" href="Style.css">
    <meta charset="utf-8">
    <audio id="audio" src="like.mp3"></audio>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>KZ GUIDE</title>
    <link rel="stylesheet" href="css/main.css">
      <link rel="stylesheet" href="popUp.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
          rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
          crossorigin="anonymous">
          <script src="main.js"></script>
          
</head>
<body>

<section class="banner" role="banner">
    <header id="header">
        <div class="header-content clearfix">

            <a class="logo"
               style="font-family: 'Segoe UI';text-transform:uppercase;font-weight: 600;color: #ffffff;text-decoration:none;font-size: 20px;"
               href="index.php">KZ Guide</a>

            <nav class="navigation" role="navigation">

                <ul class="primary-nav" style="margin-top: -0.5px;">
                    <li><a href="#features">Features</a></li>
                    <li><a href="works.php">Tours</a></li>
                    <li><a href="#testimonials">Reviews</a></li>
                    <li><a href="Sign In.php">Sign in</a></li>
                    <li><a href="Sign Up.php">Sign up</a></li>
                </ul>

            </nav>

            <a href="#" class="nav-toggle">Menu<span></span></a>
            <form class="d-flex" style="width: 400px; float: right;" method="post" action="search.php">
                <input class="form-control " type="search" placeholder="Search" name="search" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">Search</button>
              </form>

        </div>

    </header>
    <div class="container">
        <div class="col-md-12    col-md-offset-1">
            <div class="banner-text text-center">
                <h1>EXCLUSIVE TOURS IN KAZAKHSTAN</h1>
                <p>The KZ GUIDE company specializes in domestic tourism in Kazakhstan.
                    With
                    extensive experience in the tourism industry, we guarantee our customers high quality services. Our
                    team organizes tours not only to the most popular places, but also to unique and rarely visited
                    corners of the our country.</p>
            </div>
        
<div class="container">
       
        <a href="#" class="button open-popup">Contact Us</a>
      
    </div>
    


    <div class="popup-bg">
        <div class="popup">
            <img class="close-popup" src="images/close.png" alt="">
            <form action="">
                <input type="text" placeholder="Write your email">
                <input type="tel"  placeholder="Write your name">
                <input value="Send" type="submit">
            </form>
        </div>
    </div>


    


        </div>
    </div>
</section>
<section>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="Travel Makes You&nbsp;Happier, Best place in the world">
    <meta name="description" content="">
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="Главная.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 4.11.3, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,500,500i,600,600i,700,700i,800,800i,900,900i">
    
    
    <script type="application/ld+json">{
        "@context": "http://schema.org",
        "@type": "Organization",
        "name": ""
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="Главная">
    <meta property="og:type" content="website">
  </head>
  <body data-home-page="Главная.html" data-home-page-title="Главная" class="u-body u-xl-mode">
    <section class="u-clearfix u-section-1" id="carousel_1ade">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div id="carousel-f997" data-interval="5000" data-u-ride="carousel" class="u-carousel u-slider u-slider-1">
          <ol class="u-absolute-hcenter u-carousel-indicators u-carousel-indicators-1">
            <li data-u-target="#carousel-f997" class="u-active u-grey-30" data-u-slide-to="0"></li>
            <li data-u-target="#carousel-f997" class="u-grey-30" data-u-slide-to="1"></li>
          </ol>
          <div class="u-carousel-inner" role="listbox">
            <div class="u-active u-align-center u-carousel-item u-container-style u-slide">
              <div class="u-container-layout u-valign-middle u-container-layout-1">
                <h2 class="u-custom-font u-font-playfair-display u-text u-text-default u-text-1">Travel Makes You&nbsp;Happier</h2>
                <img src="images/Untitled-2.jpg" alt="" class="u-image u-image-default u-image-1" data-image-width="1600" data-image-height="1067">
                <p class="u-text u-text-2">Travel makes us happy, because it promises us the self-discovery needed to reach our goals.</p>
                <a href="buytickets.html" class="u-btn u-button-style u-palette-3-base u-btn-1">Buy right now!</a>
              </div>
            </div>
            <div class="u-align-center u-carousel-item u-container-style u-slide">
              <div class="u-container-layout u-valign-middle u-container-layout-2">
                <h2 class="u-custom-font u-font-playfair-display u-text u-text-default u-text-3">Best place in the world</h2>
                <img src="images/3.jpg" alt="" class="u-image u-image-default u-image-2" data-image-width="1096" data-image-height="1500">
                <p class="u-text u-text-4">Travel makes us happy, because it promises us the self-discovery needed to reach our goals.</p>
                <a href="buytickets.html" class="u-btn u-button-style u-palette-3-base u-btn-2">Buy right now!</a>
              </div>
            </div>
          </div>
          <a class="u-absolute-vcenter u-carousel-control u-carousel-control-prev u-palette-3-base u-spacing-10 u-text-body-color u-carousel-control-1" href="#carousel-f997" role="button" data-u-slide="prev">
            <span aria-hidden="true">
              <svg viewBox="0 0 477.175 477.175"><path d="M145.188,238.575l215.5-215.5c5.3-5.3,5.3-13.8,0-19.1s-13.8-5.3-19.1,0l-225.1,225.1c-5.3,5.3-5.3,13.8,0,19.1l225.1,225
                    c2.6,2.6,6.1,4,9.5,4s6.9-1.3,9.5-4c5.3-5.3,5.3-13.8,0-19.1L145.188,238.575z"></path></svg>
            </span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="u-absolute-vcenter u-carousel-control u-carousel-control-next u-palette-3-base u-spacing-10 u-text-body-color u-carousel-control-2" href="#carousel-f997" role="button" data-u-slide="next">
            <span aria-hidden="true">
              <svg viewBox="0 0 477.175 477.175"><path d="M360.731,229.075l-225.1-225.1c-5.3-5.3-13.8-5.3-19.1,0s-5.3,13.8,0,19.1l215.5,215.5l-215.5,215.5
                    c-5.3,5.3-5.3,13.8,0,19.1c2.6,2.6,6.1,4,9.5,4c3.4,0,6.9-1.3,9.5-4l225.1-225.1C365.931,242.875,365.931,234.275,360.731,229.075z"></path></svg>
            </span>
            <span class="sr-only">Next</span>
          </a>
        </div>
      </div>
    </section>

<section id="features" class="features section">
    <div class="container">
        <div class="row justify-content-around">
            <div class="col-md-4 col-sm-6 feature text-center">
                <span class="icon">
                    <img onmouseover="bigImg(this)" onmouseout="normalImg(this)" src="images/planet-earth.png" alt="">
                </span>
                <div class="feature-content">
                    <h5>Group and individual tours,
                        Exclusive modes of transport (VIP transfers, jeeps, buses)
                    </h5>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 feature text-center">
                <span class="icon">
                    <img onmouseover="bigImg(this)" onmouseout="normalImg(this)" src="images/forest%20(1).png" alt="">
                </span>
                <div class="feature-content">
                    <h5>Historical and archaeological excursions, master classes for students and schoolchildren</h5>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 feature text-center">
                <span class="icon">
                    <img onmouseover="bigImg(this)" onmouseout="normalImg(this)" src="images/forest.png" alt="">
                </span>
                <div class="feature-content">
                    <h5>Various outdoor activities: helicopter flights, rafting, diving, buggy, VIP tours</h5>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 feature text-center">
                <span class="icon">
                    <img onmouseover="bigImg(this)" onmouseout="normalImg(this)" src="images/mountain.png" alt="">
                </span>
                <div class="feature-content">
                    <h5>Field camp services: tents, sleeping bags, mats, kitchen equipment, tables, chairs, lighting,
                        showers, etc.</h5>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 feature text-center">
                <span class="icon">
                    <img onmouseover="bigImg(this)" onmouseout="normalImg(this)" src="images/nature.png" alt="">
                </span>
                <div class="feature-content">
                    <h5>Professional guides who speak English, French, Italian, German, Korean, Chinese, Japanese.</h5>
                </div>
            </div>

        </div>
    </div>
</section>

<section id="teams" class="section teams" style="left: 15%;">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-6 col-lg-3">
                <div class="person">
                    <img src="images/team-2.jpg" alt="" class="img-responsive">
                    <div class="person-content">
                        <h4>Samat Bugataev</h4>
                        <h5 class="role">Back-end developer</h5>
                        <p>I believe in our project, it will help you learn about unusual places in Kazakhstan.</p>
                      
                    </div>
                    <ul class="social-icons clearfix">
                        <li><a href="#" class=""><span class="fa fa-facebook"></span></a></li>
                        <li><a href="#" class=""><span class="fa fa-linkedin"></span></a></li>
                        <li><a href="#" class=""><span class="fa fa-google-plus"></span></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-6 col-sm-6 col-lg-3">
                <div class="person">
                    <img src="images/team-3.jpg" alt="" class="img-responsive">
                    <div class="person-content">
                        <h4>Gozel Yeslyamova</h4>
                        <h5 class="role">UI-UX Designer</h5>
                        <p>Customer support 24/7.
                        We accompany you throughout the trip.</p>
                    </div>
                    <ul class="social-icons clearfix">
                        <li><a href="#" class=""><span class="fa fa-facebook"></span></a></li>
                        <li><a href="#" class=""><span class="fa fa-linkedin"></span></a></li>
                        <li><a href="#" class=""><span class="fa fa-google-plus"></span></a></li>

                    </ul>
                </div>
            </div>
            <div class="col-md-6 col-sm-6 col-lg-3">
                <div class="person">
                    <img src="images/team-4.jpg" alt="" class="img-responsive">
                    <div class="person-content">
                        <h4>Assemgul Saparova</h4>
                        <h5 class="role">Front-end developer</h5>
                        <p>Customers are our main value, so we select the best offers for you!</p>
                       
                    </div>
                    <ul class="social-icons clearfix">
                        <li><a href="#" class=""><span class="fa fa-facebook"></span></a></li>
                        <li><a href="#" class=""><span class="fa fa-linkedin"></span></a></li>
                        <li><a href="#" class=""><span class="fa fa-google-plus"></span></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

</section>

<section id="testimonials" class="section testimonials no-padding">
    <div class="container">
        <div class="row no-gutter">
            <div class="col-md-6">
                <div class="avatar">
                    <img src="https://antiplagiat-killer.kz/wp-content/uploads/2020/08/obojti-antiplagiat-1.jpg" alt="" class="img-responsive">
                </div>
            </div>
            <div class="col-md-6">
                <blockquote>
                    <p id="demo">
                    </p>
                    <cite class="author">Sofia</cite>
                </blockquote>
            </div>
            
        </div>
    </div>
</section>

<footer class="footer">
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="footer-col col-md-4">
                    <h5>Location</h5>
                    <p>Mangilik El, C1 <br>
                        <span>+7 747 294 64 20 </span><br>
                        <span>info_kzguide@gmail.com</span></p>

                </div>
                <div class="footer-col col-md-4">
                    <h5>Share with Love</h5>
                    <ul class="footer-share" style="margin-left: -30px">
                        <li><a href=" https://www.facebook.com/KZ-GUIDE-101718922516197 " id="facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://www.instagram.com/kzguide_aitu/"><i class="fa fa-instagram" aria-hidden="true"></i>

                        <li><a href="bugattysam@gmail.com"><i class="fa fa-google-plus"></i></a></li>

                    </ul>

                </div>
                <div class="footer-col col-md-4">
                  <h5>About us</h5>
                    <p>EXCLUSIVE TOURS IN CENTRAL ASIA.</p>

                </div>
            </div>
        </div>
    </div>
</footer>
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script>
        <script src="popular.js"></script>
        <script src="jquery.min.js"></script>
          <script src="popUp.js"></script>
</body>

</html>

<?php 
   require_once 'include/db.php';
?>