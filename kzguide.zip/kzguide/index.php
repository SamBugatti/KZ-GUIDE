<?php 
   require_once 'include/db.php';
?>