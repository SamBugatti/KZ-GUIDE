<?php 
session_start();
   require_once '../include/db.php';

?>
<!doctype html>

<html>

<head>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<style>
.profile-head {
    transform: translateY(5rem)
}

.cover {
    background-image: url(../images/banner.jpg);
    background-size: cover;
    background-repeat: no-repeat
}

body {
    background: #654ea3;
    background: linear-gradient(to right, #003153, #904e95);
    min-height: 100vh;
    overflow-x: hidden
}
.forma{
  display: grid;
  grid-auto-rows: auto;
  margin: 70px 300px;
}

.btn {
  border: none; /* Remove borders */
  color: white; /* Add a text color */
  padding: 20px 30px; /* Add some padding */
  cursor: pointer; /* Add a pointer cursor on mouse-over */
}
.color {background-color: #2196F3;} /* Blue */
.color: hover {background: #0b7dda;}

@media screen and (max-width: 400px) {
  .forma{
    display: grid;
    grid-auto-rows: auto;
    margin: 50px 50px 50px 50px;
  }
  img{
    weight: 50%;
  }
  }

</style>

</head>

<body onload="sumOutputs();">

          <!-- Profile widget -->
          <div class="bg-white shadow rounded overflow-hidden">
              <div class="px-4 pt-0 pb-4 cover">
                  <div class="media align-items-end profile-head" style="margin-left: 60px">
                      <div class="profile mr-3"><img src="../images/profile photo.jpg" alt="..." width = "150" class="rounded mb-2 img-thumbnail">
                      </div>
                      <div class="media-body mb-5 text-white">
                          <h2 class="mt-0 mb-0"><?php echo $_SESSION['user']; ?></h2>
                          <p> <i class="fas fa-map-marker-alt mr-2"></i>User of KZ GUIDE</p>
                      </div>
                  </div>
              </div>
              <br>

              <div class="bg-light p-4 d-flex justify-content-end text-center">
                <li class="list-inline-item" style="margin-right:50%">
                        <a href="../buytickets.html"> <button class="btn color" style="margin-right: 150px;">Top up your balance</button> </a>
                    </li>
                  <ul class="list-inline mb-0"  style="margin-right: 150px">
                      <li class="list-inline-item" style="margin-right: 30px">
                        <h3><i class="bon"></i>Bonuses</h3>
                          <h5 class="font-weight-bold mb-0 d-block">0</h5>
                        </li>
                  </ul>
              </div>
              
              <div class="py-4 px-4">
                  <div class="d-flex align-items-center justify-content-between mb-3">
                      <h5 class="mb-0">Recent pictures from our tours</h5>
                      <a href="../index.php" class="btn btn-link text-muted">Go to main menu</a>
                  </div>
                  <div class="row">
                      <div class="col-lg-6 mb-2 pr-lg-1"><img src="https://images.unsplash.com/photo-1469594292607-7bd90f8d3ba4?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80" alt="" class="img-fluid rounded shadow-sm"></div>
                      <div class="col-lg-6 mb-2 pl-lg-1"><img src="https://images.unsplash.com/photo-1493571716545-b559a19edd14?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80" alt="" class="img-fluid rounded shadow-sm"></div>
                      <div class="col-lg-6 mb-2 pr-lg-1 "><img src="https://images.unsplash.com/photo-1453791052107-5c843da62d97?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80" alt="" class="img-fluid rounded shadow-sm"></div>
                      <div class="col-lg-6 pl-lg-1"><img src="https://images.unsplash.com/photo-1475724017904-b712052c192a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80" alt="" class="img-fluid rounded shadow-sm"></div>
                  </div>
              </div>
          </div>
</div>

 <script >
                 function sumOutputs2(){
                 var bn = localStorage.getItem('objectToPass2');
                document.getElementById("bon").innerHTML = bn;
                 }
                </script>

</body>

</html>
