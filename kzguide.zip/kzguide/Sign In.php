<!doctype html>

<html>

<head>

<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
* {box-sizing: border-box}

/* Full-width input fields */
  input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
    width: 100%;
  }
}

</style>

</head>

<body>


<form action="validation-form/auth.php" method="post" style="border:1px solid #ccc; margin: 70px 300px">
  <div class="container">
    <?php
      if($_COOKIE['user'] == ''):
      ?>

    <center>
    <img height="10%" width="10%" src="images/profile photo.jpg"/>
    <h1>Sign In</h1>
    <p>Please fill in this form to create an account.</p>
    </center>
    <hr>

    <label><b>Login</b></label>
    <input type="text" class="form-control" name="login" id="login" placeholder="Enter your login"> <br>

    <label><b>Password</b></label>
    <input type="password" class="form-control" name="password" id="password" placeholder="Введите пароль" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>

    <p style="margin: 5px 0 22px 0; color: red">*Only Latin letters are accepted</p>

    <label>
      <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
    </label>

    <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

    <div class="clearfix">
      <a href="index.html"><button type="button" class="cancelbtn">Cancel</button></a>
      <a href="personal page.html"><button type="submit" class="signupbtn">Sign In</button></a>
      <br>
    </div>

    <?php else:;
 ?>

 <p>Hello! <?=$_COOKIE['user']?>. If you want to exit from your account, press <a href="/validation-form/exit.php"> here</a>.</p>

 <?php endif;
 ?>
    </div>
    </form>

</body>

</html>
<?php 
   require_once 'include/db.php';
?>